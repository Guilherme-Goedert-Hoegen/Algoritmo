package Lista01;

public class AppListaUm {

	public static void main(String[] args) {
		ListaEstaticaInt lista01 = new ListaEstaticaInt();
		
		lista01.inserir(10);
		lista01.inserir(20);
		lista01.inserir(30);
		lista01.inserir(40);
		lista01.inserir(50);
		lista01.inserir(60);
		lista01.inserir(70);
		
		lista01.exibir();
	}
	
}