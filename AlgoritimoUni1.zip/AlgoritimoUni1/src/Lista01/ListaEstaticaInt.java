package Lista01;

public class ListaEstaticaInt {

	private int[] info;
	private int tamanho;
	
	/**
	 * Construtor padr�o: Cria o vetor para armazenar os dados 
	 * e estabelece que a lista est� vazia
	 */
	public ListaEstaticaInt() {
		info = new int[10];
		tamanho = 0;
	}
	
	/**
	 * Redimensiona a capacidade do vetor.
	 */
	private void redimensionar() {
		// Cria um novo vetor com o tamanho do vetor atual + 10 posi��es.
		int[] novoInfo = new int[info.length + 10];
		// Percorre o vetor atual.
		for (int indice = 0; indice < info.length; indice++) {
			// Copia o valor do indice do vetor atual, para o novo vetor na mesma posi��o
			novoInfo[indice] = info[indice];
		}
		// Atualiza a vari�vel info, para o novo vetor com maior capacidade.
		info = novoInfo;
	}
	
	/**
	 * Insere um elemento na lista.
	 * @param valor - o elemento que ser� inserido.
	 */
	public void inserir(int valor) {
		// Verifica se o vetor atual ainda tem posi��es dispon�veis.
		if (tamanho == info.length) {
			// Caso o vetor j� estiver cheio, realiza o redimensionamento.
			redimensionar();
		}
		// Insere o elemento na pr�xima posi��o dispon�vel.
		info[tamanho] = valor;
		// Incrementa a vari�vel de controle do tamanho do vetor.
		tamanho++;
	}
	
	/**
	 * Exibe as posi��es preenchidas do vetor e seus respectivos valores.
	 */
	public void exibir() {
		// Percorre o vetor.
		for (int indice = 0; indice < tamanho; indice++) {
			// Obt�m o valor do indice.
			int valor = info[indice];
			// Imprime o valor no console.
			System.out.println("[" + indice + "]: " + valor);
		}
	}
	
	/**
	 * Busca por um valor na lista, se encontrar retorna o indice do mesmo no vetor.
	 * Caso n�o encontre, retornar� -1.
	 * @param valor - o elemento que ser� pesquisado.
	 * @return um int que representa o indice do elemento no vetor.
	 */
	public int buscar(int valor) {
		// Percorre o vetor.
		for (int indice = 0; indice < tamanho; indice++) {
			// Obt�m o valor do indice.
			int valorLista = info[indice];
			// Verifica se o valor � igual ao valor informado.
			if (valorLista == valor) {
				// Caso encontar o valor, retorna o indice do mesmo.
				return indice;
			}
		}
		// Se n�o encontrou nenhum elemento igual, retorna -1.
		return -1;
	}
	
	/**
	 * Remove um elemento da lista. 
	 * @param valor - o elemento que ser� removido.
	 */
	public void retirar(int valor) {
		// Busca indice do elemento que dever� ser removido.
		int indice = buscar(valor);
		// Se encontar, realiza a remo��o.
		if (indice > -1) {
			// Percorre o vetor a partir do indice do elemento que deve ser removido.
			for (int indiceFor = indice; indiceFor < tamanho - 1; indiceFor++) {
				// Move todos os valores para a esquerda
				info[indiceFor] = info[indiceFor + 1];
			}
			// Decrementa a vari�vel de tamanho da lista.
			tamanho--;
		}
	}
	
	/**
	 * Realiza a libera��o da lista.
	 */
	public void liberar() {
		// Cria um novo vetor e atribui para a vari�vel info.
		info = new int[10];
		// Atualiza a vari�vel de controle do tamanho da lista para zero elementos.
		tamanho = 0;
	}
	
	/**
	 * Retorna o elemento baseado no indice do vetor.
	 * @param posicao - o indice que ser� utilizado para encontrar o elemento.
	 * @return o elemento da posi��o informada se existir a posi��o na lista, caso contr�rio ir� lan�ar uma exce��o.
	 */
	public int obterElemento(int posicao) {
		// Verifica se a posi��o informada � maior que zero e menor que o tamanho da lista.
		if (posicao >= 0 && (posicao < tamanho)) {
			// Se a posi��o estiver contida na lista, retorna o elemento.
			return info[posicao];
		}
		// Caso contr�rio lan�a a exce��o.
		throw new IndexOutOfBoundsException();
	}
	
	/**
	 * Retorna se a lista est� vazia.
	 * @return um valor verdadeiro se a lista estiver vazia, e um valor falso caso a lista possua algum elemento.
	 */
	public boolean estaVazia() {
		return tamanho == 0;
	}
	
	/**
	 * Retorna o tamanho da lista
	 * @return um inteiro com a quantidade de elementos da lista.
	 */
	public int getTamanho() {
		return tamanho;
	}
	
	@Override
	public String toString() {
		String resultado = "";
		// Percorre o vetor.
		for (int indice = 0; indice < tamanho; indice++) {
			// Verifica se � o primeiro elemento.
			if (indice > 0) {
				// Se n�o for o primeiro elemento, adiciona uma ",".
				resultado += ", ";
			}
			// Obt�m o valor do �ndice.
			int valor = info[indice];
			// Concatena na vari�vel de resultado.
			resultado += valor;
		}
		// Retorna o resultado, com todos os elementos separados por ",".
		return resultado;
	}
}